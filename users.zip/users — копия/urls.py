from django.urls import path
from . import views

app_name = "users"

urlpatterns = [
    path('login/', views.UserLoginView.as_view(), name='login'),
    # path('logout/', LogoutView.as_view(), name='logout'),
    path('logout/', views.logout_user, name='logout'),
    # path('register/', views.RegisterUser.as_view(), name='register'),
]
